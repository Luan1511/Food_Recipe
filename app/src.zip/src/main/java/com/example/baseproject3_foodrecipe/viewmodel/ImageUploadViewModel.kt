package com.example.baseproject3_foodrecipe.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.baseproject3_foodrecipe.util.LocalImageStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImageUploadViewModel : ViewModel() {
    // Upload status
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _isSuccess = MutableStateFlow(false)
    val isSuccess: StateFlow<Boolean> = _isSuccess

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Image path
    private val _imagePath = MutableStateFlow("")
    val imagePath: StateFlow<String> = _imagePath

    /**
     * Upload an image from URI to local storage
     */
    fun uploadImage(context: Context, imageUri: Uri, imageType: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null

                // Save image on IO dispatcher
                val path = withContext(Dispatchers.IO) {
                    LocalImageStorage.saveImage(context, imageUri)
                }

                if (path != null) {
                    _imagePath.value = path
                    _isSuccess.value = true
                } else {
                    _error.value = "Failed to save image"
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Unknown error occurred"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Reset all state values
     */
    fun reset() {
        _isLoading.value = false
        _isSuccess.value = false
        _error.value = null
        // Don't reset image path as it might be needed after upload
    }
}
