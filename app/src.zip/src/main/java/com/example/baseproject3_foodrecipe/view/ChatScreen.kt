package com.example.baseproject3_foodrecipe.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val message: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    navController: NavController
) {
    // State for chat messages
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    // For auto-scrolling to bottom
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    // Initial welcome message
    LaunchedEffect(Unit) {
        messages = listOf(
            ChatMessage(
                message = "Xin chào! Tôi là trợ lý ẩm thực AI. Bạn có thể hỏi tôi về công thức nấu ăn, mẹo nấu nướng, hoặc bất kỳ điều gì liên quan đến ẩm thực!",
                isFromUser = false
            )
        )
    }

    // Function to scroll to bottom when new message is added
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Function to handle sending a message
    fun sendMessage(text: String) {
        if (text.isBlank()) return

        // Add user message
        val userMessage = ChatMessage(message = text, isFromUser = true)
        messages = messages + userMessage
        inputText = ""
        isLoading = true
        focusManager.clearFocus()

        // Simulate AI response (would be replaced with actual API call)
        coroutineScope.launch {
            delay(1000) // Simulate network delay

            // Generate AI response based on user input
            val aiResponse = when {
                text.contains("xin chào", ignoreCase = true) ||
                        text.contains("hello", ignoreCase = true) ||
                        text.contains("hi", ignoreCase = true) ->
                    "Xin chào! Tôi có thể giúp gì cho bạn về ẩm thực hôm nay?"

                text.contains("công thức", ignoreCase = true) ||
                        text.contains("recipe", ignoreCase = true) ->
                    "Bạn muốn tìm công thức cho món ăn nào? Tôi có thể gợi ý các món phổ biến như phở, bún chả, hoặc bánh xèo."

                text.contains("phở", ignoreCase = true) ->
                    "Phở là một món ăn truyền thống của Việt Nam. Để nấu phở ngon, bạn cần: xương bò, thịt bò, gừng, hành tây, hoa hồi, quế, hạt ngò, bánh phở, hành lá, và các gia vị khác. Bạn muốn biết chi tiết cách nấu không?"

                text.contains("bánh xèo", ignoreCase = true) ->
                    "Bánh xèo là món ăn ngon của miền Nam Việt Nam. Nguyên liệu chính gồm bột gạo, nước cốt dừa, nghệ, thịt heo, tôm, giá đỗ và hành lá. Bạn cần trộn bột với nước cốt dừa và nghệ, sau đó đổ vào chảo nóng và thêm nhân."

                text.contains("cảm ơn", ignoreCase = true) ||
                        text.contains("thank", ignoreCase = true) ->
                    "Không có gì! Rất vui được giúp đỡ bạn. Bạn có câu hỏi nào khác không?"

                text.contains("mẹo", ignoreCase = true) ||
                        text.contains("tip", ignoreCase = true) ->
                    "Một mẹo nấu ăn hữu ích: Khi nấu cơm, thêm một ít dầu ăn và muối vào nước sẽ giúp cơm thơm và tơi hơn. Bạn muốn biết thêm mẹo nào khác không?"

                else -> "Tôi hiểu bạn đang hỏi về \"$text\". Đây là một chủ đề thú vị về ẩm thực. Bạn có thể cho tôi biết thêm chi tiết để tôi giúp bạn tốt hơn không?"
            }

            // Add AI response
            val aiMessage = ChatMessage(message = aiResponse, isFromUser = false)
            messages = messages + aiMessage
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trợ lý ẩm thực AI") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Chat messages
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(messages) { message ->
                    ChatMessageItem(message = message)
                }

                // Loading indicator
                if (isLoading) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFE0E0E0))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = Color(0xFF4CAF50)
                                    )
                                    Text("Đang nhập...", color = Color.DarkGray)
                                }
                            }
                        }
                    }
                }
            }

            // Input area
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        placeholder = { Text("Nhập tin nhắn...") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            sendMessage(inputText)
                        }),
                        colors = TextFieldDefaults.textFieldColors(
                            containerColor = Color(0xFFF5F5F5),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )

                    // Send button
                    IconButton(
                        onClick = { sendMessage(inputText) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF4CAF50))
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Send",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(message: ChatMessage) {
    val alignment = if (message.isFromUser) Alignment.End else Alignment.Start
    val backgroundColor = if (message.isFromUser) Color(0xFFE3F2FD) else Color(0xFFE0E0E0)
    val textColor = if (message.isFromUser) Color(0xFF1565C0) else Color.DarkGray
    val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val timeString = dateFormat.format(Date(message.timestamp))

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (message.isFromUser) 16.dp else 4.dp,
                        bottomEnd = if (message.isFromUser) 4.dp else 16.dp
                    )
                )
                .background(backgroundColor)
                .padding(12.dp)
        ) {
            Text(
                text = message.message,
                color = textColor
            )
        }

        Text(
            text = timeString,
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(4.dp),
            textAlign = if (message.isFromUser) TextAlign.End else TextAlign.Start
        )
    }
}
