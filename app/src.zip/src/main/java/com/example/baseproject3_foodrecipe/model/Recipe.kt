package com.example.baseproject3_foodrecipe.model

import java.util.UUID

data class Recipe(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val description: String = "",
    val imageUrl: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val prepTime: Int = 0,
    val cookTime: Int = 0,
    val servings: Int = 0,
    val difficulty: String = "Easy",
    val ingredients: List<String> = emptyList(),
    val instructions: List<String> = emptyList(),
    val categories: List<String> = emptyList(),
    val cuisine: String = "",
    val calories: Int = 0,
    val protein: Int = 0,
    val carbs: Int = 0,
    val fat: Int = 0,
    val rating: Double = 0.0,
    val ratingCount: Int = 0,
    val reviewCount: Int = 0,
    val youtubeVideoId: String? = null,
    val featured: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val savedRecipes: List<String> = emptyList()
) {
    val totalTime: Int
        get() = prepTime + cookTime

    val nutritionInfo: NutritionInfo?
        get() = if (protein > 0 && carbs > 0 && fat > 0) {
            NutritionInfo(protein, carbs, fat)
        } else {
            null
        }
}

data class NutritionInfo(
    val protein: Int,
    val carbs: Int,
    val fat: Int
)
