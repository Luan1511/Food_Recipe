package com.example.baseproject3_foodrecipe.model

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class BlogRepository {
    private val db = FirebaseFirestore.getInstance()
    private val blogsCollection = db.collection("blogs")
    private val usersCollection = db.collection("users")

    suspend fun createBlogPost(blogPost: BlogPost): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                blogsCollection.document(blogPost.id).set(blogPost).await()

                // Update user's blog count
                val userDoc = usersCollection.document(blogPost.authorId).get().await()
                val user = userDoc.toObject(User::class.java)

                if (user != null) {
                    val updatedBlogCount = user.blogCount + 1
                    usersCollection.document(blogPost.authorId)
                        .update("blogCount", updatedBlogCount)
                        .await()
                }

                true
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error creating blog post: ${e.message}")
            false
        }
    }

    suspend fun getBlogPost(blogId: String): BlogPost? {
        return try {
            withContext(Dispatchers.IO) {
                val document = blogsCollection.document(blogId).get().await()
                document.toObject(BlogPost::class.java)
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error getting blog post: ${e.message}")
            null
        }
    }

    suspend fun updateBlogPost(blogPost: BlogPost): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                blogsCollection.document(blogPost.id).set(blogPost).await()
                true
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error updating blog post: ${e.message}")
            false
        }
    }

    suspend fun deleteBlogPost(blogId: String, userId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get the blog to check ownership
                val blogDoc = blogsCollection.document(blogId).get().await()
                val blog = blogDoc.toObject(BlogPost::class.java)

                // Check if the user is the author
                if (blog != null && blog.authorId == userId) {
                    // Delete the blog
                    blogsCollection.document(blogId).delete().await()

                    // Update user's blog count
                    val userDoc = usersCollection.document(blog.authorId).get().await()
                    val user = userDoc.toObject(User::class.java)

                    if (user != null && user.blogCount > 0) {
                        val updatedBlogCount = user.blogCount - 1
                        usersCollection.document(blog.authorId)
                            .update("blogCount", updatedBlogCount)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error deleting blog post: ${e.message}")
            false
        }
    }

    suspend fun adminDeleteBlogPost(blogId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get the blog to find the author
                val blogDoc = blogsCollection.document(blogId).get().await()
                val blog = blogDoc.toObject(BlogPost::class.java)

                if (blog != null) {
                    // Delete the blog
                    blogsCollection.document(blogId).delete().await()

                    // Update user's blog count
                    val userDoc = usersCollection.document(blog.authorId).get().await()
                    val user = userDoc.toObject(User::class.java)

                    if (user != null && user.blogCount > 0) {
                        val updatedBlogCount = user.blogCount - 1
                        usersCollection.document(blog.authorId)
                            .update("blogCount", updatedBlogCount)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error admin deleting blog post: ${e.message}")
            false
        }
    }

    suspend fun getAllBlogs(): List<BlogPost> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = blogsCollection
                    .orderBy("publishDate", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(BlogPost::class.java) }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error getting all blogs: ${e.message}")
            emptyList()
        }
    }

    suspend fun getFeaturedBlogs(): List<BlogPost> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = blogsCollection
                    .whereEqualTo("featured", true)
                    .orderBy("publishDate", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(BlogPost::class.java) }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error getting featured blogs: ${e.message}")
            emptyList()
        }
    }

    suspend fun getBlogsByUser(userId: String): List<BlogPost> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = blogsCollection
                    .whereEqualTo("authorId", userId)
                    .orderBy("publishDate", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(BlogPost::class.java) }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error getting user blogs: ${e.message}")
            emptyList()
        }
    }

    suspend fun getBlogsByCategory(category: String): List<BlogPost> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = blogsCollection
                    .whereEqualTo("category", category)
                    .orderBy("publishDate", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(BlogPost::class.java) }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error getting blogs by category: ${e.message}")
            emptyList()
        }
    }

    suspend fun searchBlogs(query: String): List<BlogPost> {
        return try {
            withContext(Dispatchers.IO) {
                // Get all blogs and filter locally
                val snapshot = blogsCollection.get().await()
                val allBlogs = snapshot.documents.mapNotNull { it.toObject(BlogPost::class.java) }

                allBlogs.filter { blog ->
                    blog.title.contains(query, ignoreCase = true) ||
                            blog.content.contains(query, ignoreCase = true) ||
                            blog.summary.contains(query, ignoreCase = true) ||
                            blog.category.contains(query, ignoreCase = true) ||
                            blog.authorName.contains(query, ignoreCase = true)
                }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error searching blogs: ${e.message}")
            emptyList()
        }
    }

    suspend fun likeBlogPost(blogId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                val blogDoc = blogsCollection.document(blogId).get().await()
                val blog = blogDoc.toObject(BlogPost::class.java)

                if (blog != null) {
                    val updatedLikes = blog.likes + 1
                    blogsCollection.document(blogId)
                        .update("likes", updatedLikes)
                        .await()
                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error liking blog post: ${e.message}")
            false
        }
    }

    suspend fun updateCommentCount(blogId: String, increment: Boolean): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                val blogDoc = blogsCollection.document(blogId).get().await()
                val blog = blogDoc.toObject(BlogPost::class.java)

                if (blog != null) {
                    val updatedComments = if (increment) blog.comments + 1 else (blog.comments - 1).coerceAtLeast(0)
                    blogsCollection.document(blogId)
                        .update("comments", updatedComments)
                        .await()
                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("BlogRepository", "Error updating comment count: ${e.message}")
            false
        }
    }
}
