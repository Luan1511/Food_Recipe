package com.example.baseproject3_foodrecipe.model

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class RatingRepository {
    private val db = FirebaseFirestore.getInstance()
    private val ratingsCollection = db.collection("ratings")

    suspend fun getRatingsForRecipe(recipeId: String): List<Rating> {
        return try {
            val snapshot = ratingsCollection
                .whereEqualTo("recipeId", recipeId)
                .get()
                .await()

            snapshot.documents.mapNotNull { document ->
                document.toObject(Rating::class.java)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getUserRatingForRecipe(recipeId: String, userId: String): Rating? {
        return try {
            val snapshot = ratingsCollection
                .whereEqualTo("recipeId", recipeId)
                .whereEqualTo("userId", userId)
                .get()
                .await()

            if (snapshot.documents.isNotEmpty()) {
                snapshot.documents[0].toObject(Rating::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun addOrUpdateRating(rating: Rating): Boolean {
        return try {
            // Check if user already rated this recipe
            val existingRating = getUserRatingForRecipe(rating.recipeId, rating.userId)

            if (existingRating != null) {
                // Update existing rating
                ratingsCollection.document(existingRating.id)
                    .update(
                        mapOf(
                            "value" to rating.value,
                            "timestamp" to System.currentTimeMillis()
                        )
                    )
                    .await()
            } else {
                // Add new rating
                ratingsCollection.document(rating.id).set(rating).await()
            }

            // Update average rating on recipe
            updateRecipeAverageRating(rating.recipeId)

            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deleteRating(ratingId: String): Boolean {
        return try {
            val rating = getRatingById(ratingId)
            if (rating != null) {
                ratingsCollection.document(ratingId).delete().await()

                // Update average rating on recipe
                updateRecipeAverageRating(rating.recipeId)

                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun getRatingById(ratingId: String): Rating? {
        return try {
            val document = ratingsCollection.document(ratingId).get().await()
            document.toObject(Rating::class.java)
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun updateRecipeAverageRating(recipeId: String) {
        try {
            val ratings = getRatingsForRecipe(recipeId)
            if (ratings.isNotEmpty()) {
                val average = ratings.map { it.value }.average()

                // Update recipe document with new average rating and count
                db.collection("recipes").document(recipeId)
                    .update(
                        mapOf(
                            "averageRating" to average,
                            "ratingCount" to ratings.size
                        )
                    )
                    .await()
            } else {
                // No ratings, reset to default
                db.collection("recipes").document(recipeId)
                    .update(
                        mapOf(
                            "averageRating" to 0.0,
                            "ratingCount" to 0
                        )
                    )
                    .await()
            }
        } catch (e: Exception) {
            // Handle error
        }
    }

    suspend fun getUserRatings(userId: String): List<Rating> {
        return try {
            val snapshot = ratingsCollection
                .whereEqualTo("userId", userId)
                .get()
                .await()

            snapshot.documents.mapNotNull { document ->
                document.toObject(Rating::class.java)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
