package com.example.baseproject3_foodrecipe.model

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class UserRepository {
    private val db = FirebaseFirestore.getInstance()
    private val usersCollection = db.collection("users")

    suspend fun getUser(userId: String): User? {
        return try {
            withContext(Dispatchers.IO) {
                val document = usersCollection.document(userId).get().await()
                document.toObject(User::class.java)
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error getting user: ${e.message}")
            null
        }
    }

    suspend fun createUser(user: User): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                usersCollection.document(user.id).set(user).await()
                true
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error creating user: ${e.message}")
            false
        }
    }

    suspend fun updateUser(user: User): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                usersCollection.document(user.id).set(user).await()
                true
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error updating user: ${e.message}")
            false
        }
    }

    suspend fun getAllUsers(): List<User> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = usersCollection.get().await()
                snapshot.documents.mapNotNull { it.toObject(User::class.java) }
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error getting all users: ${e.message}")
            emptyList()
        }
    }

    suspend fun searchUsers(query: String): List<User> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = usersCollection.get().await()
                val allUsers = snapshot.documents.mapNotNull { it.toObject(User::class.java) }

                allUsers.filter { user ->
                    user.name.contains(query, ignoreCase = true) ||
                            user.username.contains(query, ignoreCase = true) ||
                            user.email.contains(query, ignoreCase = true) ||
                            (user.chef && user.chefTitle.contains(query, ignoreCase = true))
                }
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error searching users: ${e.message}")
            emptyList()
        }
    }

    suspend fun followUser(currentUserId: String, targetUserId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get current user
                val currentUserDoc = usersCollection.document(currentUserId).get().await()
                val currentUser = currentUserDoc.toObject(User::class.java)

                // Get target user
                val targetUserDoc = usersCollection.document(targetUserId).get().await()
                val targetUser = targetUserDoc.toObject(User::class.java)

                if (currentUser != null && targetUser != null) {
                    // Update current user's following list
                    if (!currentUser.followingUsers.contains(targetUserId)) {
                        val updatedFollowing = currentUser.followingUsers + targetUserId
                        usersCollection.document(currentUserId)
                            .update("followingUsers", updatedFollowing, "following", updatedFollowing.size)
                            .await()
                    }

                    // Update target user's followers list
                    if (!targetUser.followerUsers.contains(currentUserId)) {
                        val updatedFollowers = targetUser.followerUsers + currentUserId
                        usersCollection.document(targetUserId)
                            .update("followerUsers", updatedFollowers, "followers", updatedFollowers.size)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error following user: ${e.message}")
            false
        }
    }

    suspend fun unfollowUser(currentUserId: String, targetUserId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get current user
                val currentUserDoc = usersCollection.document(currentUserId).get().await()
                val currentUser = currentUserDoc.toObject(User::class.java)

                // Get target user
                val targetUserDoc = usersCollection.document(targetUserId).get().await()
                val targetUser = targetUserDoc.toObject(User::class.java)

                if (currentUser != null && targetUser != null) {
                    // Update current user's following list
                    if (currentUser.followingUsers.contains(targetUserId)) {
                        val updatedFollowing = currentUser.followingUsers.filter { it != targetUserId }
                        usersCollection.document(currentUserId)
                            .update("followingUsers", updatedFollowing, "following", updatedFollowing.size)
                            .await()
                    }

                    // Update target user's followers list
                    if (targetUser.followerUsers.contains(currentUserId)) {
                        val updatedFollowers = targetUser.followerUsers.filter { it != currentUserId }
                        usersCollection.document(targetUserId)
                            .update("followerUsers", updatedFollowers, "followers", updatedFollowers.size)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error unfollowing user: ${e.message}")
            false
        }
    }

    suspend fun isFollowingUser(currentUserId: String, targetUserId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                val currentUserDoc = usersCollection.document(currentUserId).get().await()
                val currentUser = currentUserDoc.toObject(User::class.java)

                currentUser?.followingUsers?.contains(targetUserId) ?: false
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error checking if following user: ${e.message}")
            false
        }
    }

    suspend fun setAdminStatus(userId: String, isAdmin: Boolean): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                usersCollection.document(userId)
                    .update("isAdmin", isAdmin)
                    .await()
                true
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error setting admin status: ${e.message}")
            false
        }
    }

    suspend fun setChefStatus(userId: String, isChef: Boolean, chefTitle: String = ""): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                val updates = mutableMapOf<String, Any>()
                updates["chef"] = isChef

                if (isChef && chefTitle.isNotEmpty()) {
                    updates["chefTitle"] = chefTitle
                }

                usersCollection.document(userId)
                    .update(updates)
                    .await()
                true
            }
        } catch (e: Exception) {
            Log.e("UserRepository", "Error setting chef status: ${e.message}")
            false
        }
    }
}
