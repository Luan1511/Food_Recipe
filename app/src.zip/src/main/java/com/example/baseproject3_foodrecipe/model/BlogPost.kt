package com.example.baseproject3_foodrecipe.model

import java.util.UUID

data class BlogPost(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val content: String = "",
    val summary: String = "",
    val imageUrl: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val publishDate: Long = System.currentTimeMillis(),
    val lastUpdated: Long = System.currentTimeMillis(),
    val readTime: Int = 5, // in minutes
    val category: String = "",
    val tags: List<String> = emptyList(),
    val likes: Int = 0,
    val views: Int = 0,
    val featured: Boolean = false,
    val commentCount: Int = 0,
    val categories: List<String> = listOf(),
    val comments: Int = 0,
    val likedBy: List<String> = emptyList(),


)
