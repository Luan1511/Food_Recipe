package com.example.baseproject3_foodrecipe.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

object LocalImageStorage {
    private const val TAG = "LocalImageStorage"
    private const val IMAGE_DIRECTORY = "recipe_images"

    fun saveImage(context: Context, imageUri: Uri): String {
        try {
            // Create directory if it doesn't exist
            val directory = File(context.filesDir, IMAGE_DIRECTORY)
            if (!directory.exists()) {
                directory.mkdirs()
            }

            // Generate unique filename
            val filename = "${UUID.randomUUID()}.jpg"
            val file = File(directory, filename)

            // Copy image to file
            context.contentResolver.openInputStream(imageUri)?.use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    val buffer = ByteArray(4 * 1024) // 4k buffer
                    var read: Int
                    while (inputStream.read(buffer).also { read = it } != -1) {
                        outputStream.write(buffer, 0, read)
                    }
                    outputStream.flush()
                }
            }

            // Return the file path
            return file.absolutePath
        } catch (e: IOException) {
            Log.e(TAG, "Error saving image: ${e.message}")
            return ""
        }
    }

    fun loadImage(path: String): Bitmap? {
        return try {
            BitmapFactory.decodeFile(path)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading image: ${e.message}")
            null
        }
    }

    fun deleteImage(path: String): Boolean {
        return try {
            val file = File(path)
            if (file.exists()) {
                file.delete()
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting image: ${e.message}")
            false
        }
    }
}
