package com.example.baseproject3_foodrecipe.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.baseproject3_foodrecipe.model.Recipe
import com.example.baseproject3_foodrecipe.model.RecipeRepository
import com.example.baseproject3_foodrecipe.util.LocalImageStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class RecipeViewModel : ViewModel() {
    private val recipeRepository = RecipeRepository()

    private val _featuredRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val featuredRecipes: StateFlow<List<Recipe>> = _featuredRecipes.asStateFlow()

    private val _popularRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val popularRecipes: StateFlow<List<Recipe>> = _popularRecipes.asStateFlow()

    private val _recentRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val recentRecipes: StateFlow<List<Recipe>> = _recentRecipes.asStateFlow()

    private val _userRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val userRecipes: StateFlow<List<Recipe>> = _userRecipes.asStateFlow()

    private val _savedRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val savedRecipes: StateFlow<List<Recipe>> = _savedRecipes.asStateFlow()

    private val _currentRecipe = MutableStateFlow<Recipe?>(null)
    val currentRecipe: StateFlow<Recipe?> = _currentRecipe.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Recipe>>(emptyList())
    val searchResults: StateFlow<List<Recipe>> = _searchResults.asStateFlow()

    private val _categoryRecipes = MutableStateFlow<List<Recipe>>(emptyList())
    val categoryRecipes: StateFlow<List<Recipe>> = _categoryRecipes.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _operationSuccess = MutableStateFlow(false)
    val operationSuccess: StateFlow<Boolean> = _operationSuccess.asStateFlow()

    init {
        loadFeaturedRecipes()
        loadPopularRecipes()
        loadRecentRecipes()
    }

    fun loadFeaturedRecipes() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getFeaturedRecipes()
                _featuredRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load featured recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadPopularRecipes() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getPopularRecipes()
                _popularRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load popular recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadRecentRecipes() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getRecentRecipes()
                _recentRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load recent recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadUserRecipes(userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getUserRecipes(userId)
                _userRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load user recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadSavedRecipes(userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getSavedRecipes(userId)
                _savedRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load saved recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getRecipeById(recipeId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipe = recipeRepository.getRecipeById(recipeId)
                _currentRecipe.value = recipe
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to get recipe: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun searchRecipes(query: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.searchRecipes(query)
                _searchResults.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to search recipes: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getRecipesByCategory(category: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getRecipesByCategory(category)
                _categoryRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to get recipes by category: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getRecipesByCuisine(cuisine: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val recipes = recipeRepository.getRecipesByCuisine(cuisine)
                _categoryRecipes.value = recipes
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Failed to get recipes by cuisine: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun saveImageAndCreateRecipe(
        context: Context,
        imageUri: Uri,
        name: String,
        description: String,
        authorId: String,
        authorName: String,
        prepTime: Int,
        cookTime: Int,
        servings: Int,
        difficulty: String,
        ingredients: List<String>,
        instructions: List<String>,
        categories: List<String>,
        cuisine: String,
        calories: Int,
        protein: Int,
        carbs: Int,
        fat: Int,
        youtubeVideoId: String? = null,
        featured: Boolean = false
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _operationSuccess.value = false

            try {
                // Save image to local storage
                val imagePath = LocalImageStorage.saveImage(context, imageUri)

                // Create recipe with image path
                createRecipe(
                    name = name,
                    description = description,
                    imageUrl = imagePath,
                    authorId = authorId,
                    authorName = authorName,
                    prepTime = prepTime,
                    cookTime = cookTime,
                    servings = servings,
                    difficulty = difficulty,
                    ingredients = ingredients,
                    instructions = instructions,
                    categories = categories,
                    cuisine = cuisine,
                    calories = calories,
                    protein = protein,
                    carbs = carbs,
                    fat = fat,
                    youtubeVideoId = youtubeVideoId,
                    featured = featured
                )
            } catch (e: Exception) {
                _errorMessage.value = "Error saving image and creating recipe: ${e.message}"
                _isLoading.value = false
            }
        }
    }

    fun createRecipe(
        name: String,
        description: String,
        imageUrl: String = "",
        authorId: String,
        authorName: String,
        prepTime: Int,
        cookTime: Int,
        servings: Int,
        difficulty: String,
        ingredients: List<String>,
        instructions: List<String>,
        categories: List<String>,
        cuisine: String,
        calories: Int,
        protein: Int,
        carbs: Int,
        fat: Int,
        youtubeVideoId: String? = null,
        featured: Boolean = false
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _operationSuccess.value = false

            try {
                val recipeId = UUID.randomUUID().toString()
                val recipe = Recipe(
                    id = recipeId,
                    name = name,
                    description = description,
                    imageUrl = imageUrl,
                    authorId = authorId,
                    authorName = authorName,
                    prepTime = prepTime,
                    cookTime = cookTime,
                    servings = servings,
                    difficulty = difficulty,
                    ingredients = ingredients,
                    instructions = instructions,
                    categories = categories,
                    cuisine = cuisine,
                    calories = calories,
                    protein = protein,
                    carbs = carbs,
                    fat = fat,
                    youtubeVideoId = youtubeVideoId,
                    featured = featured
                )

                val success = recipeRepository.createRecipe(recipe)

                if (success) {
                    _operationSuccess.value = true
                    _errorMessage.value = null

                    // Refresh recipes
                    loadRecentRecipes()
                    loadUserRecipes(authorId)
                } else {
                    _errorMessage.value = "Failed to create recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error creating recipe: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateRecipe(recipe: Recipe) {
        viewModelScope.launch {
            _isLoading.value = true
            _operationSuccess.value = false

            try {
                val success = recipeRepository.updateRecipe(recipe)

                if (success) {
                    _operationSuccess.value = true
                    _errorMessage.value = null
                    _currentRecipe.value = recipe

                    // Refresh recipes
                    loadRecentRecipes()
                    loadUserRecipes(recipe.authorId)
                } else {
                    _errorMessage.value = "Failed to update recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error updating recipe: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteRecipe(recipeId: String, userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _operationSuccess.value = false

            try {
                val success = recipeRepository.deleteRecipe(recipeId, userId)

                if (success) {
                    _operationSuccess.value = true
                    _errorMessage.value = null

                    // Refresh recipes
                    loadRecentRecipes()
                    loadUserRecipes(userId)
                } else {
                    _errorMessage.value = "Failed to delete recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error deleting recipe: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun adminDeleteRecipe(recipeId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _operationSuccess.value = false

            try {
                // Get the recipe to find the author
                val recipe = recipeRepository.getRecipeById(recipeId)
                val authorId = recipe?.authorId

                val success = recipeRepository.adminDeleteRecipe(recipeId)

                if (success) {
                    _operationSuccess.value = true
                    _errorMessage.value = null

                    // Refresh recipes
                    loadRecentRecipes()
                    if (authorId != null) {
                        loadUserRecipes(authorId)
                    }
                } else {
                    _errorMessage.value = "Failed to delete recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error deleting recipe: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun bookmarkRecipe(recipeId: String, userId: String) {
        viewModelScope.launch {
            try {
                val success = recipeRepository.bookmarkRecipe(recipeId, userId)

                if (success) {
                    // Refresh saved recipes
                    loadSavedRecipes(userId)
                } else {
                    _errorMessage.value = "Failed to bookmark recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error bookmarking recipe: ${e.message}"
            }
        }
    }

    fun unbookmarkRecipe(recipeId: String, userId: String) {
        viewModelScope.launch {
            try {
                val success = recipeRepository.unbookmarkRecipe(recipeId, userId)

                if (success) {
                    // Refresh saved recipes
                    loadSavedRecipes(userId)
                } else {
                    _errorMessage.value = "Failed to unbookmark recipe"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Error unbookmarking recipe: ${e.message}"
            }
        }
    }

    suspend fun isRecipeSaved(recipeId: String, userId: String): Boolean {
        return try {
            recipeRepository.isRecipeSaved(recipeId, userId)
        } catch (e: Exception) {
            _errorMessage.value = "Error checking if recipe is saved: ${e.message}"
            false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun resetOperationSuccess() {
        _operationSuccess.value = false
    }
}
