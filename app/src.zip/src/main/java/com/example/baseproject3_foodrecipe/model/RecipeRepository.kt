package com.example.baseproject3_foodrecipe.model

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class RecipeRepository {
    private val db = FirebaseFirestore.getInstance()
    private val recipesCollection = db.collection("recipes")
    private val usersCollection = db.collection("users")

    suspend fun createRecipe(recipe: Recipe): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                recipesCollection.document(recipe.id).set(recipe).await()

                // Update user's recipe count
                val userDoc = usersCollection.document(recipe.authorId).get().await()
                val user = userDoc.toObject(User::class.java)

                if (user != null) {
                    val updatedRecipeCount = user.recipeCount + 1
                    usersCollection.document(recipe.authorId)
                        .update("recipeCount", updatedRecipeCount)
                        .await()
                }

                true
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error creating recipe: ${e.message}")
            false
        }
    }

    suspend fun getRecipe(recipeId: String): Recipe? {
        return try {
            withContext(Dispatchers.IO) {
                val document = recipesCollection.document(recipeId).get().await()
                document.toObject(Recipe::class.java)
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting recipe: ${e.message}")
            null
        }
    }


    suspend fun updateRecipe(recipe: Recipe): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                recipesCollection.document(recipe.id).set(recipe).await()
                true
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error updating recipe: ${e.message}")
            false
        }
    }

    suspend fun deleteRecipe(recipeId: String, userId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get the recipe to check ownership
                val recipeDoc = recipesCollection.document(recipeId).get().await()
                val recipe = recipeDoc.toObject(Recipe::class.java)

                // Check if the user is the author
                if (recipe != null && recipe.authorId == userId) {
                    // Delete the recipe
                    recipesCollection.document(recipeId).delete().await()

                    // Update user's recipe count
                    val userDoc = usersCollection.document(recipe.authorId).get().await()
                    val user = userDoc.toObject(User::class.java)

                    if (user != null && user.recipeCount > 0) {
                        val updatedRecipeCount = user.recipeCount - 1
                        usersCollection.document(recipe.authorId)
                            .update("recipeCount", updatedRecipeCount)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error deleting recipe: ${e.message}")
            false
        }
    }

    // Admin có thể xóa bất kỳ công thức nào mà không cần kiểm tra quyền sở hữu
    suspend fun adminDeleteRecipe(recipeId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get the recipe to find the author
                val recipeDoc = recipesCollection.document(recipeId).get().await()
                val recipe = recipeDoc.toObject(Recipe::class.java)

                if (recipe != null) {
                    // Delete the recipe
                    recipesCollection.document(recipeId).delete().await()

                    // Update user's recipe count
                    val userDoc = usersCollection.document(recipe.authorId).get().await()
                    val user = userDoc.toObject(User::class.java)

                    if (user != null && user.recipeCount > 0) {
                        val updatedRecipeCount = user.recipeCount - 1
                        usersCollection.document(recipe.authorId)
                            .update("recipeCount", updatedRecipeCount)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error admin deleting recipe: ${e.message}")
            false
        }
    }


    suspend fun getAllRecipes(): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = recipesCollection
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(Recipe::class.java) }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting all recipes: ${e.message}")
            emptyList()
        }
    }

    suspend fun getFeaturedRecipes(): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = recipesCollection
                    .whereEqualTo("featured", true)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(Recipe::class.java) }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting featured recipes: ${e.message}")
            emptyList()
        }
    }

    suspend fun getRecipesByUser(userId: String): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = recipesCollection
                    .whereEqualTo("authorId", userId)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(Recipe::class.java) }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting user recipes: ${e.message}")
            emptyList()
        }
    }

    suspend fun getRecipesByCategory(category: String): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                val snapshot = recipesCollection
                    .whereArrayContains("categories", category)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .get()
                    .await()

                snapshot.documents.mapNotNull { it.toObject(Recipe::class.java) }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting recipes by category: ${e.message}")
            emptyList()
        }
    }

    suspend fun searchRecipes(query: String): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                // Get all recipes and filter locally
                // In a real app, you'd use Firestore's search capabilities or Algolia
                val snapshot = recipesCollection.get().await()
                val allRecipes = snapshot.documents.mapNotNull { it.toObject(Recipe::class.java) }

                allRecipes.filter { recipe ->
                    recipe.name.contains(query, ignoreCase = true) ||
                            recipe.description.contains(query, ignoreCase = true) ||
                            recipe.ingredients.any { it.contains(query, ignoreCase = true) } ||
                            recipe.instructions.any { it.contains(query, ignoreCase = true) } ||
                            recipe.categories.any { it.contains(query, ignoreCase = true) }
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error searching recipes: ${e.message}")
            emptyList()
        }
    }

    suspend fun getSavedRecipes(userId: String): List<Recipe> {
        return try {
            withContext(Dispatchers.IO) {
                // Get user's saved recipes
                val userDoc = usersCollection.document(userId).get().await()
                val user = userDoc.toObject(User::class.java)

                if (user != null && user.savedRecipes.isNotEmpty()) {
                    // Get recipes by IDs
                    val recipes = mutableListOf<Recipe>()

                    for (recipeId in user.savedRecipes) {
                        val recipeDoc = recipesCollection.document(recipeId).get().await()
                        val recipe = recipeDoc.toObject(Recipe::class.java)

                        if (recipe != null) {
                            recipes.add(recipe)
                        }
                    }

                    recipes
                } else {
                    emptyList()
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error getting saved recipes: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveRecipe(userId: String, recipeId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get user's saved recipes
                val userDoc = usersCollection.document(userId).get().await()
                val user = userDoc.toObject(User::class.java)

                if (user != null) {
                    // Add recipe to saved recipes if not already saved
                    if (!user.savedRecipes.contains(recipeId)) {
                        val updatedSavedRecipes = user.savedRecipes + recipeId
                        usersCollection.document(userId)
                            .update("savedRecipes", updatedSavedRecipes)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error saving recipe: ${e.message}")
            false
        }
    }

    suspend fun unsaveRecipe(userId: String, recipeId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get user's saved recipes
                val userDoc = usersCollection.document(userId).get().await()
                val user = userDoc.toObject(User::class.java)

                if (user != null) {
                    // Remove recipe from saved recipes
                    if (user.savedRecipes.contains(recipeId)) {
                        val updatedSavedRecipes = user.savedRecipes.filter { it != recipeId }
                        usersCollection.document(userId)
                            .update("savedRecipes", updatedSavedRecipes)
                            .await()
                    }

                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error unsaving recipe: ${e.message}")
            false
        }
    }

    suspend fun isRecipeSaved(userId: String, recipeId: String): Boolean {
        return try {
            withContext(Dispatchers.IO) {
                // Get user's saved recipes
                val userDoc = usersCollection.document(userId).get().await()
                val user = userDoc.toObject(User::class.java)

                user?.savedRecipes?.contains(recipeId) ?: false
            }
        } catch (e: Exception) {
            Log.e("RecipeRepository", "Error checking if recipe is saved: ${e.message}")
            false
        }
    }
}
