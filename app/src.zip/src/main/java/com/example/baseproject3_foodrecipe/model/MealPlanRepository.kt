package com.example.baseproject3_foodrecipe.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MealPlanRepository {
    private val db = FirebaseFirestore.getInstance()
    private val mealPlansCollection = db.collection("mealPlans")

    suspend fun getMealPlans(userId: String? = null): List<MealPlan> {
        return try {
            val query = if (userId != null) {
                mealPlansCollection.whereEqualTo("userId", userId)
            } else {
                mealPlansCollection
            }

            val snapshot = query.get().await()
            val mealPlans = mutableListOf<MealPlan>()

            for (document in snapshot.documents) {
                val id = document.id
                val userId = document.getString("userId") ?: ""

                // Handle date field properly - it could be a Timestamp, Date, or String
                val date = when (val dateField = document.get("date")) {
                    is Timestamp -> dateField.toDate()
                    is Date -> dateField
                    is String -> {
                        try {
                            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateField) ?: Date()
                        } catch (e: Exception) {
                            Date() // Fallback to current date if parsing fails
                        }
                    }
                    else -> Date() // Default to current date if field is missing or of unknown type
                }

                // Get meal items
                val breakfastMap = document.get("breakfast") as? Map<String, Any>
                val lunchMap = document.get("lunch") as? Map<String, Any>
                val dinnerMap = document.get("dinner") as? Map<String, Any>
                val snacksList = document.get("snacks") as? List<Map<String, Any>> ?: emptyList()

                val breakfast = breakfastMap?.let { mapToMealItem(it) }
                val lunch = lunchMap?.let { mapToMealItem(it) }
                val dinner = dinnerMap?.let { mapToMealItem(it) }
                val snacks = snacksList.map { mapToMealItem(it) }

                val mealPlan = MealPlan(
                    id = id,
                    userId = userId,
                    date = date,
                    breakfast = breakfast,
                    lunch = lunch,
                    dinner = dinner,
                    snacks = snacks
                )

                mealPlans.add(mealPlan)
            }

            mealPlans
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun addMealPlan(mealPlan: MealPlan) {
        try {
            val mealPlanData = hashMapOf(
                "userId" to mealPlan.userId,
                "date" to mealPlan.date, // Store as Date object directly
                "breakfast" to mealPlan.breakfast?.let { mealItemToMap(it) },
                "lunch" to mealPlan.lunch?.let { mealItemToMap(it) },
                "dinner" to mealPlan.dinner?.let { mealItemToMap(it) },
                "snacks" to mealPlan.snacks.map { mealItemToMap(it) }
            )

            mealPlansCollection.document(mealPlan.id).set(mealPlanData).await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun updateMealPlan(mealPlan: MealPlan) {
        try {
            val mealPlanData = hashMapOf(
                "userId" to mealPlan.userId,
                "date" to mealPlan.date, // Store as Date object directly
                "breakfast" to mealPlan.breakfast?.let { mealItemToMap(it) },
                "lunch" to mealPlan.lunch?.let { mealItemToMap(it) },
                "dinner" to mealPlan.dinner?.let { mealItemToMap(it) },
                "snacks" to mealPlan.snacks.map { mealItemToMap(it) }
            )

            mealPlansCollection.document(mealPlan.id).set(mealPlanData).await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun deleteMealPlan(mealPlanId: String) {
        try {
            mealPlansCollection.document(mealPlanId).delete().await()
        } catch (e: Exception) {
            throw e
        }
    }

    private fun mapToMealItem(map: Map<String, Any>): MealItem {
        return MealItem(
            id = map["id"] as? String ?: UUID.randomUUID().toString(),
            recipeId = map["recipeId"] as? String ?: "",
            recipeName = map["recipeName"] as? String ?: "",
            recipeImageUrl = map["recipeImageUrl"] as? String ?: "",
            calories = (map["calories"] as? Number)?.toInt() ?: 0,
            protein = (map["protein"] as? Number)?.toInt() ?: 0,
            carbs = (map["carbs"] as? Number)?.toInt() ?: 0,
            fat = (map["fat"] as? Number)?.toInt() ?: 0,
            tags = map["tags"] as? List<String> ?: emptyList(),
            time = map["time"] as? String ?: ""
        )
    }

    private fun mealItemToMap(mealItem: MealItem): Map<String, Any> {
        return mapOf(
            "id" to mealItem.id,
            "recipeId" to mealItem.recipeId,
            "recipeName" to mealItem.recipeName,
            "recipeImageUrl" to mealItem.recipeImageUrl,
            "calories" to mealItem.calories,
            "protein" to mealItem.protein,
            "carbs" to mealItem.carbs,
            "fat" to mealItem.fat,
            "tags" to mealItem.tags,
            "time" to mealItem.time
        )
    }
}
