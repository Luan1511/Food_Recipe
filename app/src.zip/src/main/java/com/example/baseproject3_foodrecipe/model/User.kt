package com.example.baseproject3_foodrecipe.model

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val bio: String = "",
    val profileImageUrl: String = "",
    val followers: Int = 0,
    val following: Int = 0,
    val recipeCount: Int = 0,
    val blogCount: Int = 0,
    val savedRecipes: List<String> = listOf(),
    val followingUsers: List<String> = listOf(),
    val chef: Boolean = false,
    val chefTitle: String = "",
    val isAdmin: Boolean = false, // Thêm trường isAdmin với giá trị mặc định là false
    val username: String = "",
    val followerUsers: List<String> = emptyList()
)
