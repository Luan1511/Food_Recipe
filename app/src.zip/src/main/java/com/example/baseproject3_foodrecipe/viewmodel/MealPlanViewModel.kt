package com.example.baseproject3_foodrecipe.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.baseproject3_foodrecipe.model.MealItem
import com.example.baseproject3_foodrecipe.model.MealPlan
import com.example.baseproject3_foodrecipe.model.MealPlanRepository
import com.example.baseproject3_foodrecipe.model.MealType
import com.example.baseproject3_foodrecipe.model.Recipe
import com.example.baseproject3_foodrecipe.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MealPlanViewModel(
    private val mealPlanRepository: MealPlanRepository = MealPlanRepository()
) : ViewModel() {

    private val _currentMealPlan = MutableStateFlow<MealPlan?>(null)
    val currentMealPlan: StateFlow<MealPlan?> = _currentMealPlan.asStateFlow()

    private val _selectedDate = MutableStateFlow(Date())
    val selectedDate: StateFlow<Date> = _selectedDate.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    companion object {
        val DEFAULT_MEAL_TIMES = mapOf(
            MealType.BREAKFAST to "8:00 AM",
            MealType.LUNCH to "1:00 PM",
            MealType.DINNER to "7:00 PM",
            MealType.SNACK to "4:00 PM"
        )
    }

    fun loadMealPlanForDate(date: Date) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val mealPlans = mealPlanRepository.getMealPlans()

                val existingMealPlan = mealPlans.find { mealPlan ->
                    DateUtils.isSameDay(mealPlan.date, date)
                }

                _currentMealPlan.value = existingMealPlan ?: MealPlan(
                    id = UUID.randomUUID().toString(),
                    date = date,
                    breakfast = null,
                    lunch = null,
                    dinner = null,
                    snacks = emptyList()
                )

                _isLoading.value = false
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load meal plan: ${e.message}"
                _isLoading.value = false
            }
        }
    }

    fun setSelectedDate(date: Date) {
        _selectedDate.value = date
        loadMealPlanForDate(date)
    }

    fun addMealToMealPlan(date: Date, mealType: MealType, mealItem: MealItem) {
        viewModelScope.launch {
            try {
                val mealPlans = mealPlanRepository.getMealPlans()

                val existingMealPlanIndex = mealPlans.indexOfFirst { mealPlan ->
                    DateUtils.isSameDay(mealPlan.date, date)
                }

                if (existingMealPlanIndex >= 0) {
                    // Update existing meal plan
                    val existingMealPlan = mealPlans[existingMealPlanIndex]
                    val updatedMealPlan = when (mealType) {
                        MealType.BREAKFAST -> existingMealPlan.copy(breakfast = mealItem)
                        MealType.LUNCH -> existingMealPlan.copy(lunch = mealItem)
                        MealType.DINNER -> existingMealPlan.copy(dinner = mealItem)
                        MealType.SNACK -> {
                            val updatedSnacks = existingMealPlan.snacks.toMutableList()
                            updatedSnacks.add(mealItem)
                            existingMealPlan.copy(snacks = updatedSnacks)
                        }
                    }

                    mealPlanRepository.updateMealPlan(updatedMealPlan)
                    _currentMealPlan.value = updatedMealPlan
                } else {
                    // Create new meal plan
                    val newMealPlan = when (mealType) {
                        MealType.BREAKFAST -> MealPlan(
                            id = UUID.randomUUID().toString(),
                            date = date,
                            breakfast = mealItem,
                            lunch = null,
                            dinner = null,
                            snacks = emptyList()
                        )
                        MealType.LUNCH -> MealPlan(
                            id = UUID.randomUUID().toString(),
                            date = date,
                            breakfast = null,
                            lunch = mealItem,
                            dinner = null,
                            snacks = emptyList()
                        )
                        MealType.DINNER -> MealPlan(
                            id = UUID.randomUUID().toString(),
                            date = date,
                            breakfast = null,
                            lunch = null,
                            dinner = mealItem,
                            snacks = emptyList()
                        )
                        MealType.SNACK -> MealPlan(
                            id = UUID.randomUUID().toString(),
                            date = date,
                            breakfast = null,
                            lunch = null,
                            dinner = null,
                            snacks = listOf(mealItem)
                        )
                    }

                    mealPlanRepository.addMealPlan(newMealPlan)
                    _currentMealPlan.value = newMealPlan
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to add meal: ${e.message}"
            }
        }
    }

    fun removeMealFromMealPlan(mealType: MealType) {
        val currentPlan = _currentMealPlan.value ?: return

        viewModelScope.launch {
            try {
                val updatedMealPlan = when (mealType) {
                    MealType.BREAKFAST -> currentPlan.copy(breakfast = null)
                    MealType.LUNCH -> currentPlan.copy(lunch = null)
                    MealType.DINNER -> currentPlan.copy(dinner = null)
                    MealType.SNACK -> currentPlan // Cannot remove all snacks at once
                }

                // If the meal plan is empty after removing the meal, delete it
                if (updatedMealPlan.breakfast == null &&
                    updatedMealPlan.lunch == null &&
                    updatedMealPlan.dinner == null &&
                    updatedMealPlan.snacks.isEmpty()) {
                    mealPlanRepository.deleteMealPlan(updatedMealPlan.id)
                    _currentMealPlan.value = null
                } else {
                    mealPlanRepository.updateMealPlan(updatedMealPlan)
                    _currentMealPlan.value = updatedMealPlan
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to remove meal: ${e.message}"
            }
        }
    }

    fun removeSnackFromMealPlan(snackId: String) {
        val currentPlan = _currentMealPlan.value ?: return

        viewModelScope.launch {
            try {
                val updatedSnacks = currentPlan.snacks.filter { it.id != snackId }
                val updatedMealPlan = currentPlan.copy(snacks = updatedSnacks)

                // If the meal plan is empty after removing the snack, delete it
                if (updatedMealPlan.breakfast == null &&
                    updatedMealPlan.lunch == null &&
                    updatedMealPlan.dinner == null &&
                    updatedMealPlan.snacks.isEmpty()) {
                    mealPlanRepository.deleteMealPlan(updatedMealPlan.id)
                    _currentMealPlan.value = null
                } else {
                    mealPlanRepository.updateMealPlan(updatedMealPlan)
                    _currentMealPlan.value = updatedMealPlan
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to remove snack: ${e.message}"
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }
}
