package com.example.baseproject3_foodrecipe.view

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.baseproject3_foodrecipe.util.LocalImageStorage
import com.example.baseproject3_foodrecipe.viewmodel.BlogViewModel
import com.example.baseproject3_foodrecipe.viewmodel.ImageUploadViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateBlogScreen(
    navController: NavController,
    userId: String,
    userName: String,
    blogViewModel: BlogViewModel = viewModel(),
    imageUploadViewModel: ImageUploadViewModel = viewModel()
) {
    val coroutineScope = rememberCoroutineScope()
    val isLoading by blogViewModel.isLoading.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Image upload state
    val isUploading by imageUploadViewModel.isLoading.collectAsState()
    val uploadSuccess by imageUploadViewModel.isSuccess.collectAsState()
    val uploadError by imageUploadViewModel.error.collectAsState()
    val imagePath by imageUploadViewModel.imagePath.collectAsState()

    // Blog form state
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var readTime by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var isFeatured by remember { mutableStateOf(false) }

    // Local image state
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var localBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Reset upload state when navigating to this screen
    LaunchedEffect(Unit) {
        imageUploadViewModel.reset()
    }

    // Update local bitmap when image path changes
    LaunchedEffect(imagePath) {
        if (imagePath.isNotEmpty()) {
            localBitmap = LocalImageStorage.loadImage(context, imagePath)
        }
    }

    // Show snackbar for upload status
    LaunchedEffect(uploadSuccess, uploadError) {
        if (uploadSuccess) {
            snackbarHostState.showSnackbar("Image uploaded successfully")
            imageUploadViewModel.reset()
        } else if (uploadError != null) {
            snackbarHostState.showSnackbar("Error: $uploadError")
            imageUploadViewModel.reset()
        }
    }

    // Image picker launcher
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imageUri = it
            imageUploadViewModel.uploadImage(context, it, LocalImageStorage.BLOG)
        }
    }

    // Category options
    val categoryOptions = listOf("Healthy", "Quick Meals", "Desserts", "Vegetarian", "Tips", "Baking", "Breakfast", "Dinner")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create Blog Post") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Photo Upload
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(
                            width = 1.dp,
                            color = Color.LightGray,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { imagePicker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (isUploading) {
                        // Show loading indicator
                        CircularProgressIndicator()
                    } else if (localBitmap != null) {
                        // Show local bitmap
                        Image(
                            bitmap = localBitmap!!.asImageBitmap(),
                            contentDescription = "Blog Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else if (imageUri != null) {
                        // Show selected image
                        Image(
                            painter = rememberAsyncImagePainter(imageUri),
                            contentDescription = "Blog Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        // Show placeholder
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.Image,
                                contentDescription = "Add Photo",
                                modifier = Modifier.size(48.dp),
                                tint = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Add Blog Cover Image",
                                color = Color.Gray
                            )
                        }
                    }
                }

                // Blog Title
                Text(
                    text = "Blog Title",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Enter blog title") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Summary
                Text(
                    text = "Summary",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    placeholder = { Text("Brief summary of your blog post") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    maxLines = 3
                )

                // Content
                Text(
                    text = "Content",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text("Write your blog post content here...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    maxLines = 20
                )

                // Read Time
                Text(
                    text = "Read Time (minutes)",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )
                OutlinedTextField(
                    value = readTime,
                    onValueChange = { readTime = it },
                    placeholder = { Text("5") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    trailingIcon = { Text("min") }
                )

                // Category
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium
                    )
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    categoryOptions.forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            leadingIcon = if (selectedCategory == category) {
                                {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else null
                        )
                    }
                }

                // Featured Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Featured Post",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = isFeatured,
                        onCheckedChange = { isFeatured = it }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Create Blog Button
                Button(
                    onClick = {
                        if (title.isBlank()) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Blog title cannot be empty")
                            }
                            return@Button
                        }

                        if (content.isBlank()) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Blog content cannot be empty")
                            }
                            return@Button
                        }

                        if (selectedCategory.isBlank()) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please select a category")
                            }
                            return@Button
                        }

                        coroutineScope.launch {
                            try {
                                // Create the blog post with the image path
                                blogViewModel.createBlogPost(
                                    title = title,
                                    content = content,
                                    summary = summary,
                                    imageUrl = imagePath, // Use local path
                                    authorId = userId,
                                    authorName = userName,
                                    category = selectedCategory,
                                    readTime = readTime.toIntOrNull() ?: 5,
                                    featured = isFeatured
                                )

                                snackbarHostState.showSnackbar("Blog post created successfully")
                                // Navigate back
                                navController.popBackStack()
                            } catch (e: Exception) {
                                snackbarHostState.showSnackbar("Error: ${e.message}")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("Publish Blog Post")
                }

                Spacer(modifier = Modifier.height(32.dp))
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
