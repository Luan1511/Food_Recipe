package com.example.baseproject3_foodrecipe.view

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.baseproject3_foodrecipe.ml.FoodRecognitionHelper
import com.example.baseproject3_foodrecipe.viewmodel.RecipeViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import androidx.compose.ui.graphics.Color as ComposeColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodRecognitionScreen(
    navController: NavController,
    recipeViewModel: RecipeViewModel
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var hasCameraPermission by remember { mutableStateOf(
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
    )}

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    // Yêu cầu quyền camera nếu chưa có
    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Khởi tạo FoodRecognitionHelper
    val foodRecognitionHelper = remember { FoodRecognitionHelper(context) }

    // Dọn dẹp khi màn hình bị hủy
    DisposableEffect(Unit) {
        onDispose {
            foodRecognitionHelper.close()
        }
    }

    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var previewUseCase: Preview? by remember { mutableStateOf(null) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var processedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var detections by remember { mutableStateOf<List<FoodRecognitionHelper.Detection>>(emptyList()) }
    var isProcessing by remember { mutableStateOf(false) }
    var cameraSelector by remember { mutableStateOf(CameraSelector.DEFAULT_BACK_CAMERA) }
    var showRecipeDialog by remember { mutableStateOf(false) }
    var selectedFood by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    // Dọn dẹp executor khi màn hình bị hủy
    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nhận diện thực phẩm") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (capturedBitmap == null) {
                // Hiển thị camera
                if (hasCameraPermission) {
                    CameraPreview(
                        modifier = Modifier.fillMaxSize(),
                        onUseCase = { preview, imageCaptureUseCase ->
                            previewUseCase = preview
                            imageCapture = imageCaptureUseCase
                        },
                        cameraSelector = cameraSelector
                    )

                    // Nút chụp ảnh
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 32.dp)
                    ) {
                        IconButton(
                            onClick = {
                                val imageCapture = imageCapture ?: return@IconButton

                                isProcessing = true
                                errorMessage = null

                                imageCapture.takePicture(
                                    cameraExecutor,
                                    object : ImageCapture.OnImageCapturedCallback() {
                                        override fun onCaptureSuccess(image: ImageProxy) {
                                            try {
                                                // Chuyển đổi ImageProxy thành Bitmap
                                                val bitmap = image.toBitmap()

                                                // Xoay bitmap nếu cần
                                                val matrix = Matrix().apply {
                                                    postRotate(image.imageInfo.rotationDegrees.toFloat())
                                                }

                                                val rotatedBitmap = Bitmap.createBitmap(
                                                    bitmap,
                                                    0,
                                                    0,
                                                    bitmap.width,
                                                    bitmap.height,
                                                    matrix,
                                                    true
                                                )

                                                // Cập nhật UI
                                                capturedBitmap = rotatedBitmap

                                                // Nhận diện thực phẩm trong coroutine
                                                coroutineScope.launch {
                                                    try {
                                                        val results = withContext(Dispatchers.Default) {
                                                            foodRecognitionHelper.detectFood(rotatedBitmap)
                                                        }

                                                        detections = results

                                                        // Vẽ bounding box lên ảnh
                                                        if (results.isNotEmpty()) {
                                                            processedBitmap = drawDetections(rotatedBitmap, results)
                                                        }

                                                    } catch (e: Exception) {
                                                        Log.e("FoodRecognition", "Error recognizing food", e)
                                                        errorMessage = "Lỗi khi nhận diện: ${e.message}"
                                                    } finally {
                                                        isProcessing = false
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                Log.e("FoodRecognition", "Error processing image", e)
                                                errorMessage = "Lỗi khi xử lý ảnh: ${e.message}"
                                                isProcessing = false
                                            } finally {
                                                image.close()
                                            }
                                        }

                                        override fun onError(exception: ImageCaptureException) {
                                            Log.e("FoodRecognition", "Image capture failed", exception)
                                            errorMessage = "Lỗi khi chụp ảnh: ${exception.message}"
                                            isProcessing = false
                                        }
                                    }
                                )
                            },
                            modifier = Modifier
                                .size(80.dp)
                                .background(ComposeColor.White.copy(alpha = 0.3f), CircleShape)
                                .border(2.dp, ComposeColor.White, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Camera,
                                contentDescription = "Chụp ảnh",
                                tint = ComposeColor.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    // Nút đổi camera
                    IconButton(
                        onClick = {
                            cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
                                CameraSelector.DEFAULT_FRONT_CAMERA
                            } else {
                                CameraSelector.DEFAULT_BACK_CAMERA
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(16.dp)
                            .background(ComposeColor.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = "Đổi camera",
                            tint = ComposeColor.White
                        )
                    }
                } else {
                    // Hiển thị thông báo yêu cầu quyền camera
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            modifier = Modifier.size(72.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Cần quyền truy cập camera để sử dụng tính năng này",
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                            Text("Cấp quyền")
                        }
                    }
                }
            } else {
                // Hiển thị ảnh đã chụp và kết quả nhận diện
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Hiển thị ảnh đã chụp với bounding box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        val bitmapToShow = processedBitmap ?: capturedBitmap
                        bitmapToShow?.let { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Ảnh đã chụp",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        }

                        // Nút đóng để quay lại camera
                        IconButton(
                            onClick = {
                                capturedBitmap = null
                                processedBitmap = null
                                detections = emptyList()
                                errorMessage = null
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                                .background(ComposeColor.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = ComposeColor.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Hiển thị kết quả nhận diện
                    Text(
                        text = "Kết quả nhận diện:",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isProcessing) {
                        // Hiển thị loading
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Đang nhận diện thực phẩm...")
                        }
                    } else if (errorMessage != null) {
                        // Hiển thị lỗi
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = errorMessage!!,
                                color = ComposeColor.Red,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    capturedBitmap = null
                                    processedBitmap = null
                                    errorMessage = null
                                }
                            ) {
                                Text("Thử lại")
                            }
                        }
                    } else if (detections.isEmpty()) {
                        // Không tìm thấy kết quả
                        Text(
                            text = "Không thể nhận diện thực phẩm trong ảnh. Vui lòng thử lại với ảnh khác.",
                            textAlign = TextAlign.Center,
                            color = ComposeColor.Gray
                        )
                    } else {
                        // Hiển thị danh sách kết quả
                        LazyColumn {
                            items(detections) { detection ->
                                DetectionResultItem(
                                    detection = detection,
                                    onClick = {
                                        selectedFood = detection.displayName
                                        showRecipeDialog = true
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog xác nhận tìm kiếm công thức
    if (showRecipeDialog) {
        AlertDialog(
            onDismissRequest = { showRecipeDialog = false },
            title = { Text("Tìm công thức") },
            text = { Text("Bạn muốn tìm công thức nấu ăn với ${selectedFood}?") },
            confirmButton = {
                Button(
                    onClick = {
                        showRecipeDialog = false
                        // Chuyển đến màn hình tìm kiếm với từ khóa là tên thực phẩm
                        navController.navigate("search?query=${selectedFood}")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Tìm kiếm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecipeDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

// Hàm vẽ bounding box lên ảnh
private fun drawDetections(
    bitmap: Bitmap,
    detections: List<FoodRecognitionHelper.Detection>
): Bitmap {
    // Tạo một bản sao của bitmap để vẽ lên
    val resultBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(resultBitmap)

    // Tạo paint để vẽ bounding box
    val boxPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    // Tạo paint để vẽ text
    val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        style = Paint.Style.FILL
    }

    // Tạo paint cho nền của text
    val textBackgroundPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
        alpha = 180
    }

    // Vẽ mỗi detection
    for (detection in detections) {
        val box = detection.boundingBox

        // Vẽ bounding box
        canvas.drawRect(box, boxPaint)

        // Chuẩn bị text
        val text = "${detection.displayName} ${detection.confidencePercentage}"
        val textWidth = textPaint.measureText(text)
        val textHeight = 50f

        // Vẽ nền cho text
        canvas.drawRect(
            box.left,
            box.top - textHeight,
            box.left + textWidth + 10,
            box.top,
            textBackgroundPaint
        )

        // Vẽ text
        canvas.drawText(
            text,
            box.left + 5,
            box.top - 10,
            textPaint
        )
    }

    return resultBitmap
}

@Composable
fun CameraPreview(
    modifier: Modifier = Modifier,
    onUseCase: (Preview, ImageCapture) -> Unit,
    cameraSelector: CameraSelector
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val previewView = remember { PreviewView(context) }

    LaunchedEffect(cameraSelector) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        val cameraProvider = cameraProviderFuture.get()

        // Unbind all use cases before rebinding
        cameraProvider.unbindAll()

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        val imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()

        try {
            // Bind use cases to camera
            cameraProvider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture
            )

            onUseCase(preview, imageCapture)
        } catch (e: Exception) {
            Log.e("CameraPreview", "Use case binding failed", e)
        }
    }

    AndroidView(
        factory = { previewView },
        modifier = modifier
    )
}

private fun ImageProxy.toBitmap(): Bitmap {
    val buffer = planes[0].buffer
    buffer.rewind()
    val bytes = ByteArray(buffer.capacity())
    buffer.get(bytes)
    return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
}

@Composable
fun DetectionResultItem(
    detection: FoodRecognitionHelper.Detection,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = detection.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Độ tin cậy: ${detection.confidencePercentage}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ComposeColor.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = detection.confidence,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm công thức",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
